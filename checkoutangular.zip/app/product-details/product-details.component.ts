import { Component, OnInit, Input } from '@angular/core';
import { Item } from '../items';

import { from } from 'rxjs';
import { ProductService } from '../product.service';
import { Cart } from '../shoppingcart';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
 

  constructor(private cartservice:ProductService ) { }
  @Input() 
  item :Item=new Item();
  cart:Cart=new Cart();
  
  ngOnInit(): void {
    this.cart=new Cart();
  }
  addCart()
  {
    this.cartservice.addCart(this.cart).subscribe(cart => this.cart=cart);

  }
  onSubmit(){
    this.cart.itemid=this.item.itemid;
    this.cart.sellerid=this.item.sellerid;
    this.cart.quantity=this.item.quantity;
    this.cart.price=this.item.itemCost;
 this.addCart();
  }

  

}
