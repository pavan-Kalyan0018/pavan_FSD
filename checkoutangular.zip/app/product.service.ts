import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { from, Observable } from 'rxjs';
import { Item } from './items'

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private baseUrl = 'http://localhost:8087/searchby';
  private baseUrl1='http://localhost:8082/checkout';



  constructor(private http: HttpClient) { }

  getItems(itemname: string) : Observable<any> {
    console.log(itemname);

    return this.http.get(`${this.baseUrl}/${itemname}`);
  }

  addCart(cart:object):Observable<any> {
    console.log(cart);
   return  this.http.post(`${this.baseUrl1}`,cart);
  }
}


