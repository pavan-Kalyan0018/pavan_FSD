export class Cart
{
itemid:number;
quantity:number;
price:number;
sellerid:number;
}