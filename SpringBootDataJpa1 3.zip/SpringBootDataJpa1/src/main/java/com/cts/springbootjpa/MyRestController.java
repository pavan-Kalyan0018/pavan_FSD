package com.cts.springbootjpa;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyRestController {
	
	@Autowired
	private IPersonService service;
	
	@RequestMapping("getAll")
	public List<Person> getAll(){
		
		return service.getAllPersons();
	}
	
	
	@RequestMapping("getById/{eid}")
	public Person getbyId(@PathVariable("eid") int pid) {
		Optional<Person> p=service.getPersonById(pid);
		Person pObj=null;
		if(p.isPresent()){
		 pObj=p.get();	
		}		
	
		return pObj;
	}
	
	
	
	}
	

