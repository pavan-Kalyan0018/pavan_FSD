package com.cts.springbootjpa;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


public interface IPersonService{

	public List<Person> getAllPersons();
	public Optional<Person> getPersonById(int id);
	
	

	
	
}
