package com.cts.springbootjpa;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PersonServiceImpl implements IPersonService {

	@Autowired
	private IPersonDao dao;//entity mgr factory
	
	@Override
	public List<Person> getAllPersons() {
	
		return dao.findAll();
				
	}

	@Override
	public Optional<Person> getPersonById(int id) {
		// TODO Auto-generated method stub
		return dao.findById(id);
	}

}
