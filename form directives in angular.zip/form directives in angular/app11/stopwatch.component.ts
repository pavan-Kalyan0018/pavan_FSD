import { Component } from '@angular/core';
import { interval } from 'rxjs';

@Component({
  selector: 'app-stopwatch',
  template: '<h2>{{counter}}</h2>'
})
export class StopwatchComponent {
	shouldRun:boolean = false;
	counter:number = 0;
	timeinterval:number=1000;
	interval:any;
	start() {
	      this.shouldRun = true;
		  this.interval = setInterval(() =>
  	      {  
			if(this.shouldRun === false){
			   clearInterval(this.interval);
			}
		    this.counter = this.counter + 1;			
	      }, this.timeinterval);
	}
	stop() {
	   this.shouldRun = false;
	}

	restart() {
		this.counter=0;	

	}


	slower(){
		clearInterval(this.interval);
		this.timeinterval+=1000;
		this.start();
		  
	}

faster(){

	if(this.timeinterval>1000)

	this.stop();
	this.timeinterval-=1000;
	this.start();
    }


}

    