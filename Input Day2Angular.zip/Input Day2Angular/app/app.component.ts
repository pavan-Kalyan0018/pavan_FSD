import { Component } from '@angular/core';
import {FilterData} from './filterData';
@Component({
  selector: 'app-root...........',
	template: `
	<input type="text" #filter (keyup)="0">
	<hr/><br/>
	<table style="border-style: solid; border-width:3px; align:center">
	<tr *ngFor="let point of (points | filterData: filter.value)"><br/>
	<td>{{point}}</td></tr></table>
	
	    `
})

export class AppComponent {
	
	points: string[] = [
		 'aa',
		 'afe',
		 'bb',
		 'bhe',
		 'cc',
		 'cmr',
		 'dd' ,
		 'dne',
		 'aae',
		 'aah',
		 'aam',
		 'bbm',
		 'bbr',
		 'cce',
		 'cch',
		 'ccn',
		 'ddm',
		 'ddl',
		 'ddf'
	];
	
}