package com.cts.inheritance;

public class Employee {
	private int empId;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	String empName;
	String compName;
	String dept;
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	public Employee(int id, String name, String dept2, String comp) {
		this.empId=id;
		this.compName=comp;
		this.dept=dept2;
		this.empName=name;
	}
	public void work(){
		System.out.println("working from 9 to 6");
	}
	public void checkProfile(){
		System.out.println("open profile");
	}          
}
