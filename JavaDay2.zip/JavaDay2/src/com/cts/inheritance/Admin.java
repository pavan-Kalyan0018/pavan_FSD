package com.cts.inheritance;

public class Admin extends Employee{

	public Admin() {
		// TODO Auto-generated constructor stub
	}
	public Admin(int id,String name,String dept,String comp) {
	super(id,name,dept,comp);
	System.out.println("obj of admin created ");
	}
	
	
}
