import { Component } from '@angular/core';
import { User } from './users';

@Component({
  selector: 'app-root',
  templateUrl : './app.component.html',
  styleUrls: ['./app.component.css']

})

export class AppComponent {
// isValid = true;
// ids = [1,2,3,4];
// count =0;
title = 'app';

	users:User[] = [
      new User('Mahesh', 20,'pavan@gmail.com'),
      new User('Krishna', 22,'kalyan@gmail.com'),
      new User('Narendra', 31,'ramu@gmail.com')
    ];

//     func() {

// this.count++;


//     }
    // shide() {
//    if(this.isValid){
// this.isValid=false;
//    }
    
//  else {
//   this.isValid=true;
// }
   

// this.isValid= (this.isValid) ? false : true ;





  }



