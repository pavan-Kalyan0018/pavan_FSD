package com.CartegoryRelationship.cart;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table
public class SubCategory implements Serializable {
	
	 
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	private int subcategoryid;
	@Column(name="subcategory_name")
	private String subcategoryname;
	private String briefdetails;
	private float gstpercentage;
	

	public SubCategory() {
		
	}

	public SubCategory(int subcategoryid, String subcategoryname, int categoryid, String briefdetails,
			float gstpercentage) {
		super();
		this.subcategoryid = subcategoryid;
		this.subcategoryname = subcategoryname;
		this.briefdetails = briefdetails;
		this.gstpercentage = gstpercentage;
	}

	

	public int getSubcategoryid() {
		return subcategoryid;
	}

	public void setSubcategoryid(int subcategoryid) {
		this.subcategoryid = subcategoryid;
	}

	public String getSubcategoryname() {
		return subcategoryname;
	}

	public void setSubcategoryname(String subcategoryname) {
		this.subcategoryname = subcategoryname;
	}


	public String getBriefdetails() {
		return briefdetails;
	}

	public void setBriefdetails(String briefdetails) {
		this.briefdetails = briefdetails;
	}

	public float getGstpercentage() {
		return gstpercentage;
	}

	public void setGstpercentage(float gstpercentage) {
		this.gstpercentage = gstpercentage;
	}

	@Override
	public String toString() {
		return "SubCategory [subcategoryid=" + subcategoryid + ", subcategoryname=" + subcategoryname 
				 + ", briefdetails=" + briefdetails + ", gstpercentage=" + gstpercentage + "]";
	}

	

	
}
