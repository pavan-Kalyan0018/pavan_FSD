package com.shopping.category;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import com.shopping.category.tables.Category;
import com.shopping.category.tables.SubCategory;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        Configuration configuration = new Configuration().configure();
        SessionFactory sf = configuration.buildSessionFactory();
        Session session=sf.openSession();
//        Query crit1=session.createQuery("From Category");
//    	Query crit2=session.createQuery("From SubCategory");
        Category category = new Category();
        SubCategory subcategory=new SubCategory();
        session.beginTransaction();
        session.getTransaction().commit();
        session.close();
    }
}
