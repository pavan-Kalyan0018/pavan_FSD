package com.shopping.category.tables;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity(name="ForeignKeyAssoEEntity")
@Table(name="Category_Details")
public class Category implements Serializable{
	
	private static final long serialVersionUID = -1798070786993154676L;
	
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	private int Categoryid;
	@Column(name="category_name")
	private String categoryname;
	private String briefdetails;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name="CATEGORY_ID")
	private List<SubCategory> subcategory;
	
	public Category() {
		
	}

	public int getCategoryid() {
		return Categoryid;
	}
	


	public void setCategoryid(int categoryid) {
		Categoryid = categoryid;
	}

	
	
	public List<SubCategory> getSubcategory() {
		return subcategory;
	}

	public void setSubcategory(List<SubCategory> subcategory) {
		this.subcategory = subcategory;
	}

	public String getCategoryname() {
		return categoryname;
	}

	public void setCategoryname(String categoryname) {
		this.categoryname = categoryname;
	}

	public String getBriefdetails() {
		return briefdetails;
	}

	public void setBriefdetails(String briefdetails) {
		this.briefdetails = briefdetails;
	}

	public Category(int categoryid, String categoryname, String briefdetails) {
		super();
		Categoryid = categoryid;
		this.categoryname = categoryname;
		this.briefdetails = briefdetails;
	}

	@Override
	public String toString() {
		return "Category [Categoryid=" + Categoryid + ", categoryname=" + categoryname + ", briefdetails="
				+ briefdetails + "]";
	}
	
	

}
