package com.shopping.category.tables;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity(name="ForeignKeyAssosucategoryEEntity")
@Table(name="SubCategory_Details")
public class SubCategory implements Serializable{
	
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	private int subcategoryid;
	@Column(name="SubCategory_Name")
	private String subcategoryname;
	private int categoryid;
	private String briefdetails;
	private float gstpercentage;
	
	@ManyToOne
	private Category category;
	
	public SubCategory() {
		
	}
	
	

	public Category getCategory() {
		return category;
	}



	public void setCategory(Category category) {
		this.category = category;
	}



	public int getSubcategoryid() {
		return subcategoryid;
	}

	public void setSubcategoryid(int subcategoryid) {
		this.subcategoryid = subcategoryid;
	}

	public String getSubcategoryname() {
		return subcategoryname;
	}

	public void setSubcategoryname(String subcategoryname) {
		this.subcategoryname = subcategoryname;
	}

	public int getCategoryid() {
		return categoryid;
	}

	public void setCategoryid(int categoryid) {
		this.categoryid = categoryid;
	}

	public String getBriefdetails() {
		return briefdetails;
	}

	public void setBriefdetails(String briefdetails) {
		this.briefdetails = briefdetails;
	}

	public float getGstpercentage() {
		return gstpercentage;
	}

	public void setGstpercentage(float gstpercentage) {
		this.gstpercentage = gstpercentage;
	}

	public SubCategory(int subcategoryid, String subcategoryname, int categoryid, String briefdetails,
			float gstpercentage) {
		super();
		this.subcategoryid = subcategoryid;
		this.subcategoryname = subcategoryname;
		this.categoryid = categoryid;
		this.briefdetails = briefdetails;
		this.gstpercentage = gstpercentage;
	}

	@Override
	public String toString() {
		return "SubCategory [subcategoryid=" + subcategoryid + ", subcategoryname=" + subcategoryname + ", categoryid="
				+ categoryid + ", briefdetails=" + briefdetails + ", gstpercentage=" + gstpercentage + "]";
	}

	
}
