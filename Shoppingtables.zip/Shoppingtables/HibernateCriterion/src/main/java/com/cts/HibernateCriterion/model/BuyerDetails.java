package com.cts.HibernateCriterion.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "buyer_detail")
public class BuyerDetails implements Serializable {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int buyerid;
	@Column(name = "user_name")
	private String username;
    private String password;
	private String email;
	private int mobile_no;
    @Temporal(value= TemporalType.TIMESTAMP)
	private Date createddatetime;
	public int getBuyerid() {
		return buyerid;
	}
	public void setBuyerid(int buyerid) {
		this.buyerid = buyerid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	
	public Date getCreateddatetime() {
		return createddatetime;
	}
	public void setCreateddatetime(Date createddatetime) {
		this.createddatetime = createddatetime;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(int mobile_no) {
		this.mobile_no = mobile_no;
	}
	
	
	public BuyerDetails(int buyerid, String username, String password, String email, int mobile_no,
			Date createddatetime) {
		super();
		this.buyerid = buyerid;
		this.username = username;
		this.password = password;
		this.email = email;
		this.mobile_no = mobile_no;
		this.createddatetime = createddatetime;
	}
	@Override
	public String toString() {
		return "BuyerDetails [buyerid=" + buyerid + ", username=" + username + ", password=" + password + ", email="
				+ email + ", mobile_no=" + mobile_no + ", createddatetime=" + createddatetime + "]";
	}
	
}
