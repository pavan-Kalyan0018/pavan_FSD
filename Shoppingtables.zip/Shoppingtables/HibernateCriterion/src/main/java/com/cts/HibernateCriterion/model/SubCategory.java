package com.cts.HibernateCriterion.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Sub_category")
public class SubCategory implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int subcategoryid;
	private String subcategory_name;
	private int categoryid;
	private String brief_details;
	private int gst_percentage;
	public int getSubcategoryid() {
		return subcategoryid;
	}
	public void setSubcategoryid(int subcategoryid) {
		this.subcategoryid = subcategoryid;
	}
	public String getSubcategory_name() {
		return subcategory_name;
	}
	public void setSubcategory_name(String subcategory_name) {
		this.subcategory_name = subcategory_name;
	}
	public int getCategoryid() {
		return categoryid;
	}
	public void setCategoryid(int categoryid) {
		this.categoryid = categoryid;
	}
	public String getBrief_details() {
		return brief_details;
	}
	public void setBrief_details(String brief_details) {
		this.brief_details = brief_details;
	}
	public int getGst_percentage() {
		return gst_percentage;
	}
	public void setGst_percentage(int gst_percentage) {
		this.gst_percentage = gst_percentage;
	}
	public SubCategory(int subcategoryid, String subcategory_name, int categoryid, String brief_details,
			int gst_percentage) {
		super();
		this.subcategoryid = subcategoryid;
		this.subcategory_name = subcategory_name;
		this.categoryid = categoryid;
		this.brief_details = brief_details;
		this.gst_percentage = gst_percentage;
	}
	@Override
	public String toString() {
		return "SubCategory [subcategoryid=" + subcategoryid + ", subcategory_name=" + subcategory_name
				+ ", categoryid=" + categoryid + ", brief_details=" + brief_details + ", gst_percentage="
				+ gst_percentage + "]";
	}


}
