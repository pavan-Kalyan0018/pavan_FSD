package com.cts.HibernateCriterion.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="Discount_Details")
public class DiscountsDetails implements Serializable {
	
	public DiscountsDetails(int dicountid, int discountcode, int discountpercentage, Date startdate, Date enddate) {
		super();
		this.dicountid = dicountid;
		this.discountcode = discountcode;
		this.discountpercentage = discountpercentage;
		this.startdate = startdate;
		this.enddate = enddate;
	}
	public int getDicountid() {
		return dicountid;
	}
	public void setDicountid(int dicountid) {
		this.dicountid = dicountid;
	}
	public int getDiscountcode() {
		return discountcode;
	}
	public void setDiscountcode(int discountcode) {
		this.discountcode = discountcode;
	}
	public int getDiscountpercentage() {
		return discountpercentage;
	}
	public void setDiscountpercentage(int discountpercentage) {
		this.discountpercentage = discountpercentage;
	}
	public Date getStartdate() {
		return startdate;
	}
	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}
	public Date getEnddate() {
		return enddate;
	}
	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	private int dicountid;
	@Column(name="Discount_code")
	private int discountcode;
	private int discountpercentage;
	@Column(name="Start_Date")
	@Temporal(value = TemporalType.TIMESTAMP)
	private Date startdate;
	@Column(name="End_Date")
	@Temporal(value = TemporalType.TIMESTAMP)
	private Date enddate;
	@Override
	public String toString() {
		return "DiscountsDetails [dicountid=" + dicountid + ", discountcode=" + discountcode + ", discountpercentage="
				+ discountpercentage + ", startdate=" + startdate + ", enddate=" + enddate + "]";
	}
	
	

}
