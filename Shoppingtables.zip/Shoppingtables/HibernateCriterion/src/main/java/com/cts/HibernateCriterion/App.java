package com.cts.HibernateCriterion;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
//import org.hibernate.criterion.Conjunction;
//import org.hibernate.criterion.Criterion;
//import org.hibernate.criterion.MatchMode;
//import org.hibernate.criterion.Projection;
//import org.hibernate.criterion.ProjectionList;
//import org.hibernate.criterion.Projections;
//import org.hibernate.criterion.Restrictions;

import com.cts.HibernateCriterion.model.BuyerDetails;
import com.cts.HibernateCriterion.model.Category;
import com.cts.HibernateCriterion.model.SubCategory;
import com.cts.HibernateCriterion.model.Item;
import com.cts.HibernateCriterion.model.PurchaseHistory;
import com.cts.HibernateCriterion.model.Transcations;
import com.cts.HibernateCriterion.model.DiscountsDetails;


public class App 
{
    public static void main( String[] args )
    {
    	Configuration configuration = new Configuration().configure();
		SessionFactory sf = configuration.buildSessionFactory();
		Session session = sf.openSession();
	Query crit=session.createQuery("From BuyerDetails");
	Query crit1=session.createQuery("From Category");
	Query crit2=session.createQuery("From SubCategory");
	Query crit3=session.createQuery("From Item");
	Query crit4=session.createQuery("From PurchaseHistory");
	Query crit5=session.createQuery("From Transcations");
	Query crit6=session.createQuery("From DiscountsDetails");
	
	
//		Criteria crit1 = session.createCriteria(BuyerDetails.class);
//		Projection p1 = Projections.property("first_name");
//		Projection p2 = Projections.property("hire_date");
//		ProjectionList pList = Projections.projectionList();
//		pList.add(p1);
//		pList.add(p2);
//		crit.setProjection(pList);
//		crit.add(Restrictions.like("first_name","ma%",MatchMode.ANYWHERE));
//		Criterion c1=(Restrictions.ilike("first_name","MA%",MatchMode.ANYWHERE));
//		crit.add(Restrictions.eq("hire_date", "1986-06-26"));
//		
//		Criterion crit1=Restrictions.eq("gender","M");
//		Conjunction dis = Restrictions.conjunction();
//		 dis.add(crit1); 
//		 dis.add(c1);
////		 crit.add(dis);
//		List<Employee> results = crit.list();
//		Iterator i=results.iterator();
//		while(i.hasNext()){
//			Object[] h=(Object[])i.next();
//			System.out.println(h[0]+"-------"+h[1]);
//		}
//		System.out.println(results);
//		System.out.println(crit);
//	List li=crit.list();
//	System.out.println(li);
		
		session.close();
    }
}
