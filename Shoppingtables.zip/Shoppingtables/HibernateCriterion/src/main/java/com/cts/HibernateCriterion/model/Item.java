package com.cts.HibernateCriterion.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Items_Details")
public class Item implements Serializable {
	
	
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	private int itemid; 
	@Column(name="category_id")
	private int categoryid;
	private int subcategoryid;
	private float categoryprice;
	private String itemprice;
	private String description;
	private int stock_number;
	private String remarks;


public int getItemid() {
		return itemid;
	}


	public void setItemid(int itemid) {
		this.itemid = itemid;
	}


	public int getCategoryid() {
		return categoryid;
	}


	public void setCategoryid(int categoryid) {
		this.categoryid = categoryid;
	}


	public int getSubcategoryid() {
		return subcategoryid;
	}


	public void setSubcategoryid(int subcategoryid) {
		this.subcategoryid = subcategoryid;
	}


	public float getCategoryprice() {
		return categoryprice;
	}


	public void setCategoryprice(float categoryprice) {
		this.categoryprice = categoryprice;
	}


	public String getItemprice() {
		return itemprice;
	}


	public void setItemprice(String itemprice) {
		this.itemprice = itemprice;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public int getStock_number() {
		return stock_number;
	}


	public void setStock_number(int stock_number) {
		this.stock_number = stock_number;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


public Item(int itemid, int categoryid, int subcategoryid, float categoryprice, String itemprice,
			String description, int stock_number, String remarks) {
		super();
		this.itemid = itemid;
		this.categoryid = categoryid;
		this.subcategoryid = subcategoryid;
		this.categoryprice = categoryprice;
		this.itemprice = itemprice;
		this.description = description;
		this.stock_number = stock_number;
		this.remarks = remarks;
	}


@Override
public String toString() {
	return "Item [itemid=" + itemid + ", categoryid=" + categoryid + ", subcategoryid=" + subcategoryid
			+ ", categoryprice=" + categoryprice + ", itemprice=" + itemprice + ", description=" + description
			+ ", stock_number=" + stock_number + ", remarks=" + remarks + "]";
}
}