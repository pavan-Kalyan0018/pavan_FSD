package com.cts.control;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.web.bind.annotation.ResponseBody;


@ResponseBody
public class ProductDao {
	@Autowired
	private DataSource ds;
	private JdbcTemplate jdbc;
	
	
	//setter for JDBC Template
	public void setJdbc(JdbcTemplate jdbc) {
		this.jdbc = jdbc;
	}
	
	//adding product
	public int addProduct(Product product){
		jdbc = new JdbcTemplate(ds);
		int storestatus = jdbc.update("INSERT INTO ProductDetail values(?,?,?,?)",new Object[] {product.getprodid(),product.getprodname(),product.getprodquantity(),product.getprodprice()});
		System.out.println(storestatus);
		return product.getprodid();

     }
	//get by id
	public Product getByid(int prodid) {
		jdbc = new JdbcTemplate(ds);
		String sql = "SELECT * FROM product WHERE prodid=?";
		Product product = (Product)jdbc.queryForObject(sql, new Object[] {prodid},
				new RowMapper<Product>() {

					@Override
					public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
						Product product = new Product();

						product.setprodid(rs.getInt(1));
						product.setprodname(rs.getString(2));
						product.setprodquantity(rs.getInt(3));
						product.setprodprice(rs.getFloat(4));
						
						return product;
					}
					
						
					});
		return product;
	}
	
	//Delete Product
	public int deleteProduct(int prodId) {
		jdbc = new JdbcTemplate(ds);
		int count = jdbc.update("DELETE FROM product WHERE prod_id=?", new Object[] {prodId});
		return count;
	}
	
    }

