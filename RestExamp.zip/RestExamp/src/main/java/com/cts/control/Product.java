package com.cts.control;

public class Product{
private int prodid;
private String prodname;
private int prodquantity;
private float prodprice;

public Product() {
	
}


public Product(int prodId, String prodName, int prodQuantity, float prodPrice, int prodid) {

	this.prodid = prodid;
	this.prodname = prodname;
	this.prodquantity = prodquantity;
	this.prodprice = prodprice;
}


public int getprodid() {
	return prodid;
}
public void setprodid(int prodid) {
	this.prodid = prodid;
}
public String getprodname() {
	return prodname;
}
public void setprodname(String prodName) {
	this.prodname = prodname;
}
public int getprodquantity() {
	return prodquantity;
}
public void setprodquantity(int prodquantity) {
	this.prodquantity = prodquantity;
}
public float getprodprice() {
	return prodprice;
}
public void setprodprice(float prodprice) {
	this.prodprice = prodprice;
      }
}