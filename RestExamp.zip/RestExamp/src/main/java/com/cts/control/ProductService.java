package com.cts.control;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class ProductService {
	
	@Autowired
	ProductDao pDao;


//Adding Product
	public int addProduct(Product product) {
		
		return pDao.addProduct(product);
	}
	//Get By ID
		public Product getByid(int prodid) {
			
			return pDao.getByid(prodid);
		}
		//Delete Product
		public int deleteProduct(int prodid) {
			
			return pDao.deleteProduct(prodid);
		}
	}
