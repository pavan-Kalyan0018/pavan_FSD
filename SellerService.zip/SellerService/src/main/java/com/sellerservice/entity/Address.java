/*
 * package com.sellerservice.entity;
 * 
 * import java.io.Serializable;
 * 
 * import javax.persistence.Column; import javax.persistence.Entity; import
 * javax.persistence.Table;
 * 
 * @Entity
 * 
 * @Table public class Address implements Serializable {
 * 
 * @Column private String housenumber; private String streetno; private String
 * locality; private String city; private String state; private int pincode;
 * 
 * public Address() {
 * 
 * }
 * 
 * public Address(String housenumber, String streetno, String locality, String
 * city, String state, int pincode) { super(); this.housenumber = housenumber;
 * this.streetno = streetno; this.locality = locality; this.city = city;
 * this.state = state; this.pincode = pincode; }
 * 
 * public String getHousenumber() { return housenumber; }
 * 
 * public void setHousenumber(String housenumber) { this.housenumber =
 * housenumber; }
 * 
 * public String getStreetno() { return streetno; }
 * 
 * public void setStreetno(String streetno) { this.streetno = streetno; }
 * 
 * public String getLocality() { return locality; }
 * 
 * public void setLocality(String locality) { this.locality = locality; }
 * 
 * public String getCity() { return city; }
 * 
 * public void setCity(String city) { this.city = city; }
 * 
 * public String getState() { return state; }
 * 
 * public void setState(String state) { this.state = state; }
 * 
 * public int getPincode() { return pincode; }
 * 
 * public void setPincode(int pincode) { this.pincode = pincode; }
 * 
 * @Override public String toString() { return "Address [housenumber=" +
 * housenumber + ", streetno=" + streetno + ", locality=" + locality + ", city="
 * + city + ", state=" + state + ", pincode=" + pincode + "]"; }
 * 
 * 
 * }
 */