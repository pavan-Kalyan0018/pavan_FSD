package com.sellerservice.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Table
public class Items implements Serializable{

	@Id
	@GeneratedValue( strategy = GenerationType.AUTO)
	private int itemid;
	 @ManyToOne
	 @JoinColumn(name = "category_id_ref")
	 @OnDelete(action = OnDeleteAction.CASCADE) private Category category;
	 @ManyToOne
	 @JoinColumn(name = "sub_categoryid_ref")
	 @OnDelete(action = OnDeleteAction.CASCADE) private SubCategory subcategory;
	 @Column
	 private Double  itemCost;
	 private String itemName;
	 private String itemDescription;
	 private String remarks;
	 
	 public Items() {
		 
	 }

	public Items(int itemid, Category category, SubCategory subcategory, Double itemCost, String itemName,
			String itemDescription, String remarks) {
		super();
		this.itemid = itemid;
		this.category = category;
		this.subcategory = subcategory;
		this.itemCost = itemCost;
		this.itemName = itemName;
		this.itemDescription = itemDescription;
		this.remarks = remarks;
	}

	public int getItemid() {
		return itemid;
	}

	public void setItemid(int itemid) {
		this.itemid = itemid;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public SubCategory getSubcategory() {
		return subcategory;
	}

	public void setSubcategory(SubCategory subcategory) {
		this.subcategory = subcategory;
	}

	public Double getItemCost() {
		return itemCost;
	}

	public void setItemCost(Double itemCost) {
		this.itemCost = itemCost;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@Override
	public String toString() {
		return "Items [itemid=" + itemid + ", category=" + category + ", subcategory=" + subcategory + ", itemCost="
				+ itemCost + ", itemName=" + itemName + ", itemDescription=" + itemDescription + ", remarks=" + remarks
				+ "]";
	}
	 
	 
}
