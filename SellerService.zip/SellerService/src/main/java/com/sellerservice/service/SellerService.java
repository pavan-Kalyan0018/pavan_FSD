package com.sellerservice.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sellerservice.dao.CategoryDao;
import com.sellerservice.dao.ItemsDao;
import com.sellerservice.dao.SellerDao;
import com.sellerservice.dao.SubCategoryDao;
import com.sellerservice.entity.Category;
import com.sellerservice.entity.Items;
import com.sellerservice.entity.Seller;
import com.sellerservice.entity.SubCategory;

@Service
public class SellerService implements Iseller {

	@Autowired
	private SellerDao dao;
	@Autowired
	private CategoryDao categorydao;
	@Autowired
	private SubCategoryDao subcategorydao;
	@Autowired
	private ItemsDao itemsdao;
	@Override
	public List<Seller> getAll() {
		
		return dao.findAll();
	}
	@Override
	public Seller add(Seller seller) {
		
		return dao.save(seller);
	}
	@Override
	public Seller getUser(int id) {
	
		Optional<Seller> seller = dao.findById(id);
		return seller.get();
	}
	@Override
	public Seller updateSeller(Seller seller, int id) {
		Optional<Seller> seller1 = dao.findById(id);
		
//		Seller seller1 = dao.getOne(id);
		if (seller1 != null) {

			//  int sellersellerid=seller.getSellerid(); 
			  String username=seller.getUsername(); 
			  String password=seller.getPassword(); 
			  String emailId=seller.getEmailId(); 
			  String address=seller.getAddress();
			  String companyname=seller.getCompanyname();
			  String briefaboutcompany=seller.getBriefaboutcompany();
			  String website=seller.getWebsite();
			  Double gstin=seller.getGstin();
			  String contactnumber=seller.getContactnumber();
			  System.out.println("enter into info"); 
			//  seller1.get().setSellerid(sellersellerid);
			  seller1.get().setUsername(username); 
			  seller1.get().setPassword(password);
			  seller1.get().setEmailId(emailId); 
			  seller1.get().setAddress(address);
			  seller1.get().setBriefaboutcompany(briefaboutcompany);
			  seller1.get().setContactnumber(contactnumber);
			  seller1.get().setCompanyname(companyname);
			  seller1.get().setGstin(gstin);
			  seller1.get().setWebsite(website);
			 
			 

		} else {
			
		}
		
	return dao.save(seller);
	}
	
	
	
	// Items Service
	@Override
	public List<Items> getAllItems() {
		
		return itemsdao.findAll();
	}
	@Override
	public Items add(Items items) {
	
		return itemsdao.save(items);
	}
	@Override
	public Items getProduct(int id) {
		
		Optional<Items> items= itemsdao.findById(id);
		return items.get();
	}
	@Override
	public Items updateItems(Items items, int id) {
		
		
		Optional<Items> items1=itemsdao.findById(id);
		if(items1!=null) {
			Double itemcost=items.getItemCost();
			String itemname=items.getItemName();
			String itemdescription=items.getItemDescription();
			int quantity=items.getQuantity();
			String model=items.getModel();
			String manfacture=items.getManfacture();
			  System.out.println("enter into info");
			  items1.get().setItemCost(itemcost);
			  items1.get().setItemName(itemname);
			  items1.get().setItemDescription(itemdescription);
			  items1.get().setQuantity(quantity);
			  items1.get().setModel(model);
			  items1.get().setManfacture(manfacture);
			  
			  
		}
		else {
			
		}
		
		return itemsdao.save(items);
	}
	@Override
	public int deleteItems(Items items, int id) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
	
	
}




