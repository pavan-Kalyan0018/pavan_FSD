package com.sellerservice.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sellerservice.dao.SellerDao;
import com.sellerservice.entity.Category;
import com.sellerservice.entity.Items;
import com.sellerservice.entity.Seller;
import com.sellerservice.entity.SubCategory;

@Service
public class SellerService implements Iseller {

	@Autowired
	private SellerDao dao;
	@Autowired
	private Category categorydao;
	@Autowired
	private SubCategory subcategorydao;
	@Autowired
	private Items itemsdao;

	// Seller Service
	@Override

	public List<Seller> getAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public Seller add(Seller seller) {
		// TODO Auto-generated method stub
		return dao.save(seller);
	}

//	@Override
//	public Seller getUser(int sellerid) {
//		// TODO Auto-generated method stub
//		return null;
//	}

	@Override
	public Seller updateSeller(Seller seller, int sellerid) {
		// TODO Auto-generated method stub
		return null;
	}

@Override
public Seller getUser(int sellerid) {
	// TODO Auto-generated method stub
	return null;
}



//	@Override
//	public Seller getUser(int id) {
//		return dao.findOne(id);
//	}

//	@Override
//	public Seller updateSeller(Seller seller, int sellerid) {
////		Seller seller1 = dao.findById(sellerid);
//		if (seller2 != null) {
//			
//			  int sellersellerid=seller.getSellerid(); 
//			  String username=seller.getUsername(); 
//			  String password=seller.getPassword(); 
//			  String emailId=seller.getEmailId(); 
//			  String companyname=seller.getCompanyname();
//			  String briefaboutcompany=seller.getBriefaboutcompany();
//			  String website=seller.getWebsite();
//			  Double gstin=seller.getGstin();
//			  String contactnumber=seller.getContactnumber();
//			  System.out.println("enter into info"); 
//			  seller1.setSellerid(sellersellerid);
//			  seller1.setUsername(username); 
//			  seller1.setPassword(password);
//			  seller1.setEmailId(emailId); 
//			  seller1.setBriefaboutcompany(briefaboutcompany);
//			  seller1.setContactnumber(contactnumber);
//			  seller1.setCompanyname(companyname);
//			  seller1.setGstin(gstin);
//			  seller1.setWebsite(website);
//			 
//			 
//
//		} else {
//
//		}
//		return dao.save(seller);
//
//	}

}
