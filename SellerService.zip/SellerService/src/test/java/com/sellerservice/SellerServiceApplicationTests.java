package com.sellerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SellerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
