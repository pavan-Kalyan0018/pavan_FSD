package com.cts.springbootjpa.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Category { 
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int categoryId;
	private String categoryName;
	private String briefdetails;
	public Category() 
	{ 
		
	}
	public Category(int categoryId, String categoryName, String briefdetails) {
		super();
		this.categoryId = categoryId;
		this.categoryName = categoryName;
		this.briefdetails = briefdetails;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getBriefdetails() {
		return briefdetails;
	}
	public void setBriefdetails(String briefdetails) {
		this.briefdetails = briefdetails;
	}
	@Override
	public String toString() {
		return "Category [categoryId=" + categoryId + ", categoryName=" + categoryName + ", briefdetails="
				+ briefdetails + "]";
	}
    
}
