package com.cts.hibernate.HibernateBasics;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Conjunction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.cts.hibernate.model.Employee;

public class App {
	public static void main(String[] args) {
		Configuration configuration = new Configuration().configure();
		SessionFactory sf = configuration.buildSessionFactory();
		Session session = sf.openSession();
		// Query crit=session.createQuery("From Employee");
		Criteria crit = session.createCriteria(Employee.class);
		Projection p1 = Projections.property("first_name");
		Projection p2 = Projections.property("hire_date");
		ProjectionList pList = Projections.projectionList();
		pList.add(p1);
		pList.add(p2);
		crit.setProjection(pList);
		// crit.add(pList);
		// crit.add(Restrictions.like("first_name","%"));
		// crit.addOrder(Order.desc("first_name"));
		List<Employee> results = crit.list();
		Iterator i=results.iterator();
		while(i.hasNext()){
			Object[] h=(Object[])i.next();
			System.out.println(h[0]+"-------"+h[1]);
		}
		System.out.println(results);

		// Criterion
		// c1=Restrictions.like("first_name","yutr%",MatchMode.ANYWHERE);
		// Criterion c2=Restrictions.eq("gender","M");
		// crit.add(Restrictions.eq("hire_date", "1986-06-26"));
		// crit.add(Restrictions.like("first_name","Su%",MatchMode.ANYWHERE));
		// crit.add(Restrictions.eq("gender","M"));
		Conjunction dis = Restrictions.conjunction();
		/*
		 * dis.add(c1); dis.add(c2); crit.add(dis);
		 */// List li=crit.list();
			// System.out.println(li);
		session.close();

	}
}
