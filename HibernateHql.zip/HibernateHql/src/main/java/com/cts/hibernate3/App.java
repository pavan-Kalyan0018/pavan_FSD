package com.cts.hibernate3;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.cts.hibernate3.control.OrderItem;

public class App {
	
	
	public static void main(String[] args) {
		Configuration configuration = new Configuration().configure();
		SessionFactory sf = configuration.buildSessionFactory();
		Session session = sf.openSession();
		
		
		Query q1=session.getNamedQuery("retrieveCount");
		q1.setFetchSize(3);
		System.out.println(q1.list());
		
		
//		Query q=session.getNamedQuery("retrieveall");   
//		q.setFirstResult(2);
//		q.setFetchSize(3);
//		System.out.println(q.list());
		
		
//		Query q=session.createSQLQuery("select * from Order_Item");
//		System.out.println(q.list());
		
		
//		String hql = "from OrderItem o where o.orderId =?";
//		Query q = session.createQuery(hql);
//		q.setParameter(0, 5);
//		List result = q.list();
//		System.out.println(result);
//		
//		
//		OrderItem order=new OrderItem(); order.setOrderId(5); String hql =
//				  "from OrderItem o where o.orderId = :orderId"; List result =
//				  session.createQuery(hql).setProperties(order).list();
//				  System.out.println(result);
//				 
		
		
//		Query query = session.createQuery(
//		   "from OrderItem o where o.id = :id "); query.setParameter("id", 1003);
//		   List<OrderItem> list=query.list(); System.out.println(list);
		
		
//		String qry="select order.buyingPrice FROM OrderItem order"; 
//		Query q=session.createQuery(qry); 
//		List<OrderItem> ll=q.list();
//		  System.out.println(ll);
				  
				  
//		OrderItem order=new OrderItem(1110,5,6,10,103,788.7f);
//		 session.beginTransaction();
//		 session.save(order);
//		  session.getTransaction().commit();
		  session.close();
	
     }
}