package com.cts.HibernateCriterion;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Conjunction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;

import com.cts.HibernateCriterion.model.Employee;

public class App 
{
    public static void main( String[] args )
    {
    	Configuration configuration = new Configuration().configure();
		SessionFactory sf = configuration.buildSessionFactory();
		Session session = sf.openSession();
//		Query crit=session.createQuery("From Employee");
		Criteria crit = session.createCriteria(Employee.class);
		crit.add(Restrictions.ilike("first_name","BO%",MatchMode.ANYWHERE));
		List<Employee> results = crit.list();
//		Iterator i=results.iterator();
//		while(i.hasNext()){
//			Object[] h=(Object[])i.next();
//			System.out.println(h[0]+"-------"+h[1]);
//		}
		System.out.println(results);
		
	
		
		session.close();
    }
}
