package com.cts.hibernate4.HibernateCriterion;


public class AppTest 
    
{
    
}
