package com.cts;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//public abstract class javax.servlet.GenericServlet implements javax.servlet.Servlet
//public abstract class javax.servlet.http.HttpServlet extends javax.servlet.GenericServlet {
public class MyServlet extends HttpServlet {
	private PrintWriter out=null;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		out=resp.getWriter();
		//for(int i=0;i<4;i++)
		int a=Integer.parseInt(req.getParameter("numb"));
		if(a%2==0)
		out.println("<h1>number is even </h1>");
		else
		out.println("<h1>number is odd</h1>");	
	}

}


