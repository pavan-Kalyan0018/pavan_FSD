import { Component, OnInit, Input } from '@angular/core';
import { Item } from '../items';

import { from } from 'rxjs';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
 

  constructor( ) { }
  @Input() item :Item
  
  ngOnInit(): void {
  }

  

}
