import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { from, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private baseUrl = 'http://localhost:8087/searchby';



  constructor(private http: HttpClient) { }

  getItems(itemname: string) : Observable<any> {

    return this.http.get(`${this.baseUrl}/${itemname}`);
  }
}


