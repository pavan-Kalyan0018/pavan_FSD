package com.ui;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public class EmpDao {
	
	public int addProduct(Product pdt) throws SQLException{
		String qry="insert INTO Product values(?,?,?,?)";
		Connection conn=DbUtil.getConnectionForDb();
		PreparedStatement pst=conn.prepareStatement(qry);
		pst.setInt(1, pdt.getProdId());
		pst.setString(2, pdt.getProdName());
		pst.setInt(3, pdt.getQuantity());
		pst.setFloat(4,pdt.getPrice());
		
		int prodId=pst.executeUpdate();
		if(prodId>0){
			prodId=pdt.getProdId();
		}
		return prodId;
	}
	
	public Product getProductById(int pdtId) throws SQLException{
		String qry="SELECT * FROM Product WHERE prod_id=?";
		Connection conn=DbUtil.getConnectionForDb();
		PreparedStatement pst=conn.prepareStatement(qry);
		pst.setInt(1,pdtId);
		ResultSet ts=pst.executeQuery();
		Product p=null;
		if(ts.next()){
			p=new Product(ts.getInt(1),ts.getString(2),ts.getInt(3),ts.getFloat(4));
		}
		return p;
	}
	
	public List<Product> getAllProducts() throws SQLException{
		String qry="SELECT * FROM Product";
		Connection conn=DbUtil.getConnectionForDb();
		PreparedStatement pst=conn.prepareStatement(qry);
		ResultSet ts=pst.executeQuery();
		Product p=null;
		List<Product> pList=new ArrayList<>();
		while(ts.next()){
			p=new Product(ts.getInt(1),ts.getString(2),ts.getInt(3),ts.getFloat(4));
			pList.add(p);
		}
		return pList;
	}

}
