package com.ui;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

public class EmpService {
	
	private EmpDao edao=null;
	
	public int addProduct(Product pdt) throws SQLException{
		edao=new EmpDao();
		//validation logic to be done here
		return edao.addProduct(pdt);
	}
	
	public Product getProductById(int pdtId) throws SQLException{
		edao=new EmpDao();
		return edao.getProductById(pdtId);
	}
	
	public List<Product> getAllProducts() throws SQLException{
		edao=new EmpDao();
		return edao.getAllProducts(); 
	}
}
