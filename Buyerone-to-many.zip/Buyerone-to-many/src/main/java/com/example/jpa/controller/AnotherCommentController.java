package com.example.jpa.controller;

import com.example.jpa.exception.ResourceNotFoundException;
import com.example.jpa.model.AnotherComment;
import com.example.jpa.repository.AnotherCommentRepository;
import com.example.jpa.repository.BuyerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
public class AnotherCommentController {

    @Autowired
    private AnotherCommentRepository anotherCommentRepository;

    @Autowired
    private BuyerRepository buyerRepository;

    @GetMapping("/posts/{postId}/anothercomments")
    public Page<AnotherComment> getAllCommentsByPostId(@PathVariable (value = "postId") Long postId,
                                                Pageable pageable) {
        return anotherCommentRepository.findByBuyerId(postId, pageable);
    }

    @PostMapping("/posts/{postId}/anothercomments")
    public AnotherComment createComment(@PathVariable (value = "postId") Long postId,
                                 @Valid @RequestBody AnotherComment comment) {
        return buyerRepository.findById(postId).map(buyer -> {
            comment.setBuyer(buyer);
            return anotherCommentRepository.save(comment);
        }).orElseThrow(() -> new ResourceNotFoundException("PostId " + postId + " not found"));
    }

    @PutMapping("/posts/{postId}/anothercomments/{commentId}")
    public AnotherComment updateComment(@PathVariable (value = "postId") Long postId,
                                 @PathVariable (value = "commentId") Long commentId,
                                 @Valid @RequestBody AnotherComment commentRequest) {
        if(!buyerRepository.existsById(postId)) {
            throw new ResourceNotFoundException("PostId " + postId + " not found");
        }

        return anotherCommentRepository.findById(commentId).map(comment -> {
            comment.setText(commentRequest.getText());
            return anotherCommentRepository.save(comment);
        }).orElseThrow(() -> new ResourceNotFoundException("CommentId " + commentId + "not found"));
    }

    @DeleteMapping("/posts/{postId}/anothercomments/{commentId}")
    public ResponseEntity<?> deleteComment(@PathVariable (value = "postId") Long postId,
                              @PathVariable (value = "commentId") Long commentId) {
        return anotherCommentRepository.findByIdAndBuyerId(commentId, postId).map(comment -> {
            anotherCommentRepository.delete(comment);
            return ResponseEntity.ok().build();
        }).orElseThrow(() -> new ResourceNotFoundException("Comment not found with id " + commentId + " and postId " + postId));
    }
}
